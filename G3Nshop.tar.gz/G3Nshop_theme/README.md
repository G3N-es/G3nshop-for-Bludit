# G3Nshop_theme for Bludit
G3Nshop_theme is an adaptation of theme Mediumish for the G3Nshop online store plugin.
Mediumish is a Bludit theme like Medium. Similar look and feel, Mediumish is the perfect blog or shop theme.

## Features
- Bootstrap 4.0
- Responsive
- Cross Browser Compatible
- Masonry
- Font Awesome

## Base on
- Mediumish - Free Bootstrap 4.0 HTML Template Medium Styled
- https://www.wowthemes.net/mediumish-free-bootstrap-4-0-html-template-medium-styled/

## Compatible
- Bludit v3.x

## Author
- G3N.es | Miguel Lacha

## License
- Freebies License. https://www.wowthemes.net/freebies-license/

