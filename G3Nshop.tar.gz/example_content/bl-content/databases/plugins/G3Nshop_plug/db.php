<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{"categoria":"tienda","moneda":"EUR","position":1,"cuentaPaypal":"dsfsadfaf@GDFGADG.COM","modoPruebas":"1"}